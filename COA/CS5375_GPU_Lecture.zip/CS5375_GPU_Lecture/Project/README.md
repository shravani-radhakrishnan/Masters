Matrix Multiplication Kernel
======================

**Texas Tech University, CS5375 Computer Systems Organization and Architecture, Project**

* (TODO) YOUR NAME HERE
  * (TODO) R# HERE.
  * (TODO) TTU e-mail HERE.

### (TODO: Your README)

Include comments and analysis, etc.
