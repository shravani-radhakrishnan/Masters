1. Installations and Setup:
---------------------------
Install Python 3 version
Install PIP
Install pyvis
Install pandas
Install matplotlib

2. Running:
-------------------

- python3 main.py
- In chromeBrowser open index.html

3. File Structure
-------------------

Data.csv - Node connections Data
main.py  - python code which create network using the Data.csv and create a histogram
index.html -  Which will be generate once running the main.py


