from ntpath import join
from turtle import color
from numpy import size
from pyvis.network import Network
import pandas as pd
import matplotlib.pyplot as plt
import networkx as nx
import csv
# from numbers_parser import Document


got_net = Network(height='1000px', width='100%')

# set the physics layout of the network
got_data = pd.read_csv('data.csv',nrows=200)

sources = got_data['Source']
targets = got_data['Target']

edge_data = zip(sources, targets )

for e in edge_data:
    src = str(e[0])
    dst = str(e[1])
    
    w = 3
    if(e[0]==0):
        weight = 1
    else:
        weight = e[0]

    got_net.add_node(src,size=weight,title=src,labelHighlightBold='true',color="#2880B9",borderWidthSelected="2")
    got_net.add_node(dst,size=weight,title=dst,labelHighlightBold='true',color="#1880B9",borderWidthSelected="2")
    got_net.add_edge(src,dst, value=w,color="#a9dcf2")

neighbor_map = got_net.get_adj_list()

# add neighbor data to node hover data

for node in got_net.nodes:
    node_array = len(neighbor_map[node['id']])
    node['title'] +='- Node<br>' + 'No of connections:<br>' + str(node_array) +'<br>'+' Neighbor Ids:<br>' + '<br>'.join(neighbor_map[node['id']])
    node['value'] = len(neighbor_map[node['id']])
    node['size'] = len(neighbor_map[node['id']])

# got_net.options.layout.set_edge_minimization
got_net.show('index.html')

H =nx.Graph()

with open('nodes_data.txt') as f:
    lines = f.readlines()

# reading each line from the lines object to get data
for line in lines:
    s = int(line.split("\t")[0])    # accessing the source Node
    d = int(line.split("\t")[1])    # accessing the destination Node
    H.add_node(s)
    H.add_node(d)
    H.add_edge(s, d)

# plot Histogram
def plot_chart(H):
    degrees = [val for (node, val) in H.degree()]
    fig, axs = plt.subplots(1, 1)
    axs.hist(degrees, bins =100)
    axs.set_yscale('log')
    # plt.show()
    plt.title("Degree Distribution of node in unidirected Graph")
    plt.ylabel('Count(Log Scale')
    plt.xlabel('Node degree')
    plt.show()

plot_chart(H)