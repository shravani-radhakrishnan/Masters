"""Custom topology example

Two directly connected switches plus a host for each switch:

   host --- switch --- switch --- host

Adding the 'topos' dict with a key/value pair to generate our newly defined
topology enables one to pass in '--topo=mytopo' from the command line.
"""

from mininet.topo import Topo

class MyTopo( Topo ):

	def build( self ):
	
		#Reading the routers_data from the given text file
		with open('routers_data_undirected.txt') as f:
			lines = f.readlines()
			
		routers = {}
		servers = {}
		clients = {}
		#Looping the nodes data from the text file
		for line in lines:
			s = int(line.split("\t")[0])
			t = int(line.split("\t")[1])
			#Group no is 27 so reading 1350 to 1400 nodes if 				nodes greater than 1400 break
			if s >= 1350 and s <= 1400:
				if t >= 1350 and t <= 1400:
				 	servers[s] = self.addHost('s'+str(s))
					clients[s] = self.addHost('c'+str(s))
					routers[s] = self.addSwitch('r'+str(s))
					routers[t] = self.addSwitch('r'+str(t))
					
					self.addLink(clients[s], routers[s])
					self.addLink(servers[s], routers[s])
					self.addLink(routers[s], routers[t])
					self.addLink(routers[s], servers[s])
					self.addLink(routers[s], clients[s])

			if source > 1400:
				break

        

topos = { 'mytopo': ( lambda: MyTopo() ) }

