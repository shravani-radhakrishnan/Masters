Project-2 Details: Group number- 27

1.router ID range (1350 router ID to 1400 router ID) from the given file.

2.Configuration & Installation instructions:
	1. Installed Oracle VM Ware.
	2. Installed Ubuntu in VM Ware.
	3. Installed Mininet.
	4. To install Mininet need git.
	5. Install Python.

3.Operating Instructions:
	Commands to run:
		1. To create a file --> vim main.py
		2. Open a file by using vim main.py
		3. edit the file by typing 'i' 
		4. Once changes are done click Esc and :wq
		5. To execute the code sudo mn --custom ~/main.py --topo mytopo --test pingall
		6. After this command Host,swtiches and connection will happen and pings to all routers 
		   once execution is done will exit.
	
4.Contact info of Authors:
	Roopa Singamaneni (R11793654)--> Section - 002
	Sravani Bodempudi (R11779743)--> Section - 002
	Sravani Manduva   (R11800063)--> Section - 003
	Shiny Gutta       (R11795062)--> Section - 003
	Sri Nagini Ette   (R11802264)--> Section - 002


