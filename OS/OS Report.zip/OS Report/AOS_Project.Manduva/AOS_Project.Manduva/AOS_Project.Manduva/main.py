import psutil
from round_robin import robin_main
from priority import priority_main
import plotly.express as px
import matplotlib.pyplot as plts
import numpy as np
from threading import Thread
from multiprocessing import Process
import os
import openpyxl
import numpy as np
import pandas as pd
import common

# Choose which File Needs to be run
def chooseSchedulerToRun():
    val = input("Name the scheduler you want to run 'round_robin' or 'priority' or 'both' :")
    n = input("Number of processors:")
    n = int(n)
    resp = common.RandomNumberGenerator(n)
    if val=='round_robin':
        data = common.round(resp)
        resp = robin_main(data,n)
    elif val=='priority':
        data = common.prio(resp)
        priority_main(data,n)
    else:
        os.environ['selected']='both'
        data1 = common.round(resp)
        data2 = common.prio(resp)
        process1 = Process(target=robin_main,args=(data1,n))
        process2 = Process(target=priority_main,args=(data2,n))
        process1.start()
        process2.start()
        process1.join()
        process2.join()
        excelData()

def main():
    chooseSchedulerToRun()

# Read Excel File
def excelData():
    df1=pd.read_excel('roundrobin.xlsx')
    df1=df1.transpose()
    df1.to_excel('roundrobin.xlsx')
    wb=openpyxl.load_workbook('roundrobin.xlsx')
    ws=wb['Sheet1']
    ws['A1']='RESOURCES'
    ws['B1']='USAGE'
    wb.save('roundrobin.xlsx')
    df1=pd.read_excel('roundrobin.xlsx')
    df1=df1.drop(df1.index[0])
    df1.to_excel('roundrobin.xlsx',index=False)

    df2=pd.read_excel('priority.xlsx')
    df2=df2.transpose()
    df2.to_excel('priority.xlsx')
    wb=openpyxl.load_workbook('priority.xlsx')
    ws=wb['Sheet1']
    ws['A1']='RESOURCES'
    ws['B1']='USAGE'
    wb.save('priority.xlsx')
    df2=pd.read_excel('priority.xlsx')
    df2=df2.drop(df2.index[0])
    df2.to_excel('priority.xlsx',index=False)

    labels = []
    labels = df1['RESOURCES']
    selection_list = df1['USAGE']
    shell_list = df2['USAGE']
    x = np.arange(len(labels)) 
    width = 0.35  
    fig, ax = plts.subplots()

    rects1 = ax.bar(x - width/2, selection_list, width, label='Round Robin')
    rects2 = ax.bar(x + width/2, shell_list, width, label='Priority')

    ax.set_xticks(x, labels)
    ax.legend()


    ax.bar_label(rects1, padding=3)
    ax.bar_label(rects2, padding=3)

    fig.tight_layout()
    plts.title("Priority & Round-Robin Scheduling Algorithm")
    plts.show()




if __name__ == "__main__": main()


