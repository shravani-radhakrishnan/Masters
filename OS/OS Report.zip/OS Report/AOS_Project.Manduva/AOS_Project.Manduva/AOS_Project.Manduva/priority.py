import psutil
import os
from datetime import datetime
import matplotlib.pyplot as plt
import csv
import pandas as pd
import time
# Priority Scheduling

# Function to find the waiting time
# for all processes
def findWaitingTime(processes, n, wt):
	wt[0] = 0

	# calculating waiting time
	for i in range(1, n):
		wt[i] = processes[i - 1][1] + wt[i - 1]

# Function to calculate turn around time
def findTurnAroundTime(processes, n, wt, tat):
	
	# Calculating turnaround time by
	for i in range(n):
		tat[i] = processes[i][1] + wt[i]

# Function to calculate average waiting and turn-around times.
def findavgTime(processes, n, p,start_time):
	wt = [0] * n
	tat = [0] * n

	# Function to find waiting time of all processes
	findWaitingTime(processes, n, wt)

	# Function to find turn around time
	findTurnAroundTime(processes, n, wt, tat)

	# Display processes along with all details
	print(" (Process) (Burst Time) (Waiting Time) (Turn Around Time)")
	total_wt = 0
	total_tat = 0
	for i in range(n):

		total_wt = total_wt + wt[i]
		total_tat = total_tat + tat[i]
		print("P", processes[i][0], "\t\t",
				processes[i][1], "\t\t",
				wt[i], "\t\t", tat[i])

	print("\nAverage waiting time = %.5f "%(total_wt /n))
	print("Average turn around time = ", total_tat / n)
	end_time = time.time()
	if os.getenv("selected"):
		value = os.environ['selected']
	else:
		value="priority"
	
	resp = Calc(p,start_time,end_time)
	labels = ['CPU Usage','Disk Usage','Memory Usage','VMS','RSS','Page Fault','Time']
	if value=="priority":
		PlotChart(resp)
	else:
		with open('priority.csv','w',newline="") as rd:
			writer=csv.writer(rd)
			writer.writerow(labels)
			writer.writerow(resp)
		rf=pd.read_csv('priority.csv',delimiter=',')
		df=rf.to_excel('priority.xlsx') 


def priorityScheduling(proc, n, p,start_time):
	
	# Sort processes by priority
	proc = sorted(proc, key = lambda proc:proc[2],
								reverse = True)

	print("-----Order in which processes gets executed the process----")
	for i in proc:
		print(i[0], end = " ")
	findavgTime(proc, n, p,start_time)
    
def priority_main(data,n):

	p2 = os.getpid()
	print("Process Id for priority",p2)
	proc = data
    # Process id's
	start_time = time.time()
	priorityScheduling(proc, n, p2,start_time)

# Calculate the utilization data
def Calc(pid,start,end):
	pid = os.getpid()
	py = psutil.Process(pid)
	print("User Information for Round-Robin:",pid)
	print("--------------------------------------")
	
	## Time 
	time_Spend = round((end-start)*1000)
	print("Running time of Round-Robin:",time_Spend,"ms\n")
	
	## cpu usage

	cpu_percentage = psutil.cpu_percent()
	print("System level information for Priority:")
	print("--------------------------------------")
	print("CPU usage for Priority:",cpu_percentage,"%")


    ## memory usage
	print("Memory Usage for Priority:",py.memory_percent())
	memory_percentage = py.memory_percent()
	
    ## memory usage
	memory_percent = float("{:.2f}".format(py.memory_percent()))
	memory = psutil.virtual_memory()
	memory_string = str(memory)
	memory_list=memory_string.split(",")
	total_memory = int(memory_list[0].split("=")[1])
	memory_in_bytes = "{:.2f}".format((total_memory*memory_percent)/100)
	memory_in_bytes = float(memory_in_bytes)/(1024*1024)

    ## hard drive usage
	io_counters = py.io_counters()
	io_counters_string = str(io_counters)
	io_counters_list = io_counters_string.split(",")
	io_counters_read_bytes = int(io_counters_list[2].split("=")[1])
	io_counters_write_bytes = int(io_counters_list[3].split("=")[1])
	total_io_counters_bytes = io_counters_read_bytes+io_counters_write_bytes

	disk_counters = psutil.disk_io_counters()
	disk_counters_string = str(disk_counters)
	disk_counters_list = disk_counters_string.split(",")
	disk_counters_read_bytes = int(disk_counters_list[2].split("=")[1])
	disk_counters_write_bytes = int(disk_counters_list[3].split("=")[1])
	total_disk_counters_bytes = disk_counters_read_bytes+disk_counters_write_bytes

	disk_usage = (total_io_counters_bytes/total_disk_counters_bytes)*100

    ## full memory info
	full_memory_info=str(py.memory_info())
	full_memory_list = full_memory_info.split(",")
	rss=full_memory_list[0].split('=')[1]
	vms=full_memory_list[1].split('=')[1]
	page_faults=full_memory_list[2].split('=')[1]
	RSS=int(rss)*0.00000095367432
	VMS=int(vms)*0.00000095367432
	print('RSS for Priority:', RSS, "GB")
	# page_faults_new= int(page_faults)/10
	print('VMS for Priority:', VMS, "GB")
	page_faults = py.memory_info()[2]

	print('page_faults for Priority:', page_faults)
	print('VMS for Priority:', VMS)
	print('RSS for Priority:', RSS)
	print('Time spend:', time_Spend)
	data = [cpu_percentage,disk_usage,memory_in_bytes,VMS,RSS,page_faults,time_Spend]
	return data


def PlotChart(data):
    labels = ['CPU Usage','Disk Usage','Memory Usage','VMS','RSS','Page Fault','Time']
    fig = plt.figure(figsize = (7, 3))
    plt.bar(labels, data, color ='Green', width = 0.3)
    plt.title("Priority Scheduling Algorithm")
    plt.show()



# Driver code
if __name__ =="__main__":priority_main()


    
