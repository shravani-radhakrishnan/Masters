import psutil
import os
from datetime import datetime
# Priority Scheduling

# Function to find the waiting time
# for all processes
def findWaitingTime(processes, n, wt):
	wt[0] = 0

	# calculating waiting time
	for i in range(1, n):
		wt[i] = processes[i - 1][1] + wt[i - 1]

# Function to calculate turn around time
def findTurnAroundTime(processes, n, wt, tat):
	
	# Calculating turnaround time by
	# adding bt[i] + wt[i]
	for i in range(n):
		tat[i] = processes[i][1] + wt[i]

# Function to calculate average waiting
# and turn-around times.
def findavgTime(processes, n, p):
	wt = [0] * n
	tat = [0] * n

	# Function to find waiting time
	# of all processes
	findWaitingTime(processes, n, wt)

	# Function to find turn around time
	# for all processes
	findTurnAroundTime(processes, n, wt, tat)

	# Display processes along with all details
	print(" (Process) (Burst Time) (Waiting Time) (Turn Around Time)")
	total_wt = 0
	total_tat = 0
	for i in range(n):

		total_wt = total_wt + wt[i]
		total_tat = total_tat + tat[i]
		print("P", processes[i][0], "\t\t",
				processes[i][1], "\t\t",
				wt[i], "\t\t", tat[i])

	print("\nAverage waiting time = %.5f "%(total_wt /n))
	print("Average turn around time = ", total_tat / n)
	Calc(p)


def priorityScheduling(proc, n, p):
	
	# Sort processes by priority
	proc = sorted(proc, key = lambda proc:proc[2],
								reverse = True)

	print("Order in which processes gets executed")
	for i in proc:
		print(i[0], end = " ")
	findavgTime(proc, n, p)
    
def priority_main(data,n):

	p2 = os.getpid()
	print("Process Id for priority",p2,datetime.now())
	proc = data
    # Process id's
	priorityScheduling(proc, n, p2)

def Calc(p):
	pr=psutil.Process(p)
	 ## cpu usage
	cpu_usage_percent = psutil.cpu_percent(interval=1, percpu=True)

    ## memory usage
	memory_percent = float("{:.2f}".format(pr.memory_percent()))
	memory = psutil.virtual_memory()
	memory_string = str(memory)
	print(memory_string)
	print(memory_string.split(","))
	memory_list=memory_string.split(",")
	total_memory = int(memory_list[0].split("=")[1])
	print(total_memory)
	memory_in_bytes = "{:.2f}".format((total_memory*memory_percent)/100)
	memory_in_bytes = float(memory_in_bytes)/(1024*1024)
	print("memory used: ", memory_in_bytes)

    ## hard drive usage
	io_counters = pr.io_counters()
	print(io_counters)
	io_counters_string = str(io_counters)
	io_counters_list = io_counters_string.split(",")
	io_counters_read_bytes = int(io_counters_list[2].split("=")[1])
	io_counters_write_bytes = int(io_counters_list[3].split("=")[1])
	total_io_counters_bytes = io_counters_read_bytes+io_counters_write_bytes

	disk_counters = psutil.disk_io_counters()
	print(disk_counters)
	disk_counters_string = str(disk_counters)
	disk_counters_list = disk_counters_string.split(",")
	disk_counters_read_bytes = int(disk_counters_list[2].split("=")[1])
	disk_counters_write_bytes = int(disk_counters_list[3].split("=")[1])
	total_disk_counters_bytes = disk_counters_read_bytes+disk_counters_write_bytes

	disk_usage = (total_io_counters_bytes/total_disk_counters_bytes)*100
	print(disk_usage)

    ## full memory info
	full_memory_info=str(pr.memory_info())
	print(full_memory_info)
	full_memory_list = full_memory_info.split(",")
	print(full_memory_list)
	rss=full_memory_list[0].split('=')[1]
	print(rss)
	vms=full_memory_list[1].split('=')[1]
	print(vms)
	page_faults=full_memory_list[2].split('=')[1]
	print(page_faults)
    # print(type(rss),type(vms),int(rss))
	rss_new=int(rss)*0.00000095367432
	vms_new=int(vms)*0.00000095367432
	page_faults_new= int(page_faults)/10


# Driver code
if __name__ =="__main__":priority_main()


    
